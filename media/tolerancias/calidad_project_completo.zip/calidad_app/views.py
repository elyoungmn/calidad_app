from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Lote, Proyecto
from .forms import LoteForm

@login_required
def registrar_lote(request):
    if request.method == 'POST':
        form = LoteForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('ver_lotes')
    else:
        form = LoteForm()
        form.fields['proyecto'].queryset = Proyecto.objects.filter(empresa=request.user.empresa)
    return render(request, 'registrar_lote.html', {'form': form})

@login_required
def ver_lotes(request):
    lotes = Lote.objects.filter(proyecto__empresa=request.user.empresa)
    return render(request, 'ver_lotes.html', {'lotes': lotes})

@login_required
def ver_proyectos(request):
    proyectos = Proyecto.objects.filter(empresa=request.user.empresa)
    return render(request, 'proyectos.html', {'proyectos': proyectos})

@login_required
def lotes_por_proyecto(request, proyecto_id):
    proyecto = get_object_or_404(Proyecto, id=proyecto_id, empresa=request.user.empresa)
    lotes = Lote.objects.filter(proyecto=proyecto)
    return render(request, 'lotes_por_proyecto.html', {'proyecto': proyecto, 'lotes': lotes})
