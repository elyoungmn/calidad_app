from django.urls import path
from . import views

urlpatterns = [
    path('', views.ver_proyectos, name='ver_proyectos'),
    path('proyecto/<int:proyecto_id>/', views.lotes_por_proyecto, name='lotes_por_proyecto'),
    path('registrar/', views.registrar_lote, name='registrar_lote'),
    path('lotes/', views.ver_lotes, name='ver_lotes'),
]
