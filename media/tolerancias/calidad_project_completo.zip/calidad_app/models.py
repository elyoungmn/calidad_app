from django.db import models
from django.contrib.auth.models import User

class Empresa(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Proyecto(models.Model):
    nombre = models.CharField(max_length=100)
    empresa = models.ForeignKey(Empresa, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

class Lote(models.Model):
    id_lote = models.CharField(max_length=20, unique=True)
    proyecto = models.ForeignKey(Proyecto, on_delete=models.CASCADE)
    fecha_registro = models.DateTimeField(auto_now_add=True)
    analisis_espectrometrico = models.FileField(upload_to='analisis/', null=True, blank=True)
    tolerancia_geometrica = models.FileField(upload_to='tolerancias/', null=True, blank=True)
    numero_de_partes = models.FileField(upload_to='partes/', null=True, blank=True)
    prueba_dureza = models.FileField(upload_to='dureza/', null=True, blank=True)
    plano_original = models.FileField(upload_to='planos/', null=True, blank=True)
    evidencia_fotografica = models.FileField(upload_to='evidencias/', null=True, blank=True)

    def __str__(self):
        return self.id_lote
