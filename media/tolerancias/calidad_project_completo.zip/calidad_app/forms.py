from django import forms
from .models import Lote

class LoteForm(forms.ModelForm):
    class Meta:
        model = Lote
        fields = [
            'id_lote',
            'proyecto',
            'analisis_espectrometrico',
            'tolerancia_geometrica',
            'numero_de_partes',
            'prueba_dureza',
            'plano_original',
            'evidencia_fotografica',
        ]
