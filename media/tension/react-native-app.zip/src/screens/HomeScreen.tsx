"use client"

import { useState } from "react"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import Icon from "react-native-vector-icons/Ionicons"

interface Task {
  id: string
  title: string
  completed: boolean
}

export default function HomeScreen({ navigation }: any) {
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", title: "Completar proyecto React Native", completed: false },
    { id: "2", title: "Revisar documentación", completed: true },
    { id: "3", title: "Hacer ejercicio", completed: false },
  ])
  const [newTask, setNewTask] = useState("")

  const addTask = () => {
    if (newTask.trim()) {
      const task: Task = {
        id: Date.now().toString(),
        title: newTask,
        completed: false,
      }
      setTasks([...tasks, task])
      setNewTask("")
    }
  }

  const toggleTask = (id: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const deleteTask = (id: string) => {
    Alert.alert("Eliminar tarea", "¿Estás seguro de que quieres eliminar esta tarea?", [
      { text: "Cancelar", style: "cancel" },
      { text: "Eliminar", onPress: () => setTasks(tasks.filter((task) => task.id !== id)) },
    ])
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Mi Lista de Tareas</Text>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Agregar nueva tarea..."
            value={newTask}
            onChangeText={setNewTask}
            onSubmitEditing={addTask}
          />
          <TouchableOpacity style={styles.addButton} onPress={addTask}>
            <Icon name="add" size={24} color="white" />
          </TouchableOpacity>
        </View>

        <View style={styles.tasksContainer}>
          {tasks.map((task) => (
            <View key={task.id} style={styles.taskItem}>
              <TouchableOpacity style={styles.taskContent} onPress={() => toggleTask(task.id)}>
                <Icon
                  name={task.completed ? "checkmark-circle" : "ellipse-outline"}
                  size={24}
                  color={task.completed ? "#4CAF50" : "#ccc"}
                />
                <Text style={[styles.taskText, task.completed && styles.completedTask]}>{task.title}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteButton} onPress={() => deleteTask(task.id)}>
                <Icon name="trash-outline" size={20} color="#FF5252" />
              </TouchableOpacity>
            </View>
          ))}
        </View>

        <TouchableOpacity
          style={styles.detailButton}
          onPress={() => navigation.navigate("Detail", { taskCount: tasks.length })}
        >
          <Text style={styles.detailButtonText}>Ver Estadísticas</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
    textAlign: "center",
  },
  inputContainer: {
    flexDirection: "row",
    marginBottom: 20,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    backgroundColor: "white",
    fontSize: 16,
  },
  addButton: {
    backgroundColor: "#007AFF",
    borderRadius: 8,
    padding: 12,
    marginLeft: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  tasksContainer: {
    marginBottom: 20,
  },
  taskItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  taskContent: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
  },
  taskText: {
    fontSize: 16,
    marginLeft: 12,
    color: "#333",
  },
  completedTask: {
    textDecorationLine: "line-through",
    color: "#999",
  },
  deleteButton: {
    padding: 5,
  },
  detailButton: {
    backgroundColor: "#4CAF50",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },
  detailButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
})
