import { View, Text, StyleSheet, ScrollView, Dimensions } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import Icon from "react-native-vector-icons/Ionicons"

const { width } = Dimensions.get("window")

export default function DetailScreen({ route }: any) {
  const { taskCount = 0 } = route.params || {}

  const stats = [
    { label: "Total de Tareas", value: taskCount, icon: "list-outline", color: "#007AFF" },
    { label: "Completadas", value: Math.floor(taskCount * 0.6), icon: "checkmark-circle-outline", color: "#4CAF50" },
    { label: "Pendientes", value: Math.floor(taskCount * 0.4), icon: "time-outline", color: "#FF9800" },
    { label: "Productividad", value: "85%", icon: "trending-up-outline", color: "#9C27B0" },
  ]

  const weeklyData = [
    { day: "Lun", completed: 3, pending: 1 },
    { day: "Mar", completed: 5, pending: 2 },
    { day: "Mié", completed: 2, pending: 3 },
    { day: "Jue", completed: 4, pending: 1 },
    { day: "Vie", completed: 6, pending: 0 },
    { day: "Sáb", completed: 1, pending: 2 },
    { day: "Dom", completed: 2, pending: 1 },
  ]

  const maxValue = Math.max(...weeklyData.map((d) => d.completed + d.pending))

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Estadísticas Detalladas</Text>

        <View style={styles.statsGrid}>
          {stats.map((stat, index) => (
            <View key={index} style={styles.statCard}>
              <Icon name={stat.icon} size={32} color={stat.color} />
              <Text style={styles.statValue}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.chartContainer}>
          <Text style={styles.chartTitle}>Actividad Semanal</Text>
          <View style={styles.chart}>
            {weeklyData.map((data, index) => {
              const completedHeight = (data.completed / maxValue) * 120
              const pendingHeight = (data.pending / maxValue) * 120

              return (
                <View key={index} style={styles.chartBar}>
                  <View style={styles.barContainer}>
                    <View style={[styles.bar, styles.pendingBar, { height: pendingHeight }]} />
                    <View style={[styles.bar, styles.completedBar, { height: completedHeight }]} />
                  </View>
                  <Text style={styles.dayLabel}>{data.day}</Text>
                </View>
              )
            })}
          </View>

          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: "#4CAF50" }]} />
              <Text style={styles.legendText}>Completadas</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: "#FF9800" }]} />
              <Text style={styles.legendText}>Pendientes</Text>
            </View>
          </View>
        </View>

        <View style={styles.insightsContainer}>
          <Text style={styles.insightsTitle}>Insights</Text>

          <View style={styles.insightCard}>
            <Icon name="trophy-outline" size={24} color="#FFD700" />
            <View style={styles.insightText}>
              <Text style={styles.insightTitle}>¡Excelente trabajo!</Text>
              <Text style={styles.insightDescription}>Has completado el 85% de tus tareas esta semana.</Text>
            </View>
          </View>

          <View style={styles.insightCard}>
            <Icon name="calendar-outline" size={24} color="#007AFF" />
            <View style={styles.insightText}>
              <Text style={styles.insightTitle}>Mejor día</Text>
              <Text style={styles.insightDescription}>
                Los viernes son tu día más productivo con 6 tareas completadas.
              </Text>
            </View>
          </View>

          <View style={styles.insightCard}>
            <Icon name="bulb-outline" size={24} color="#FF9800" />
            <View style={styles.insightText}>
              <Text style={styles.insightTitle}>Sugerencia</Text>
              <Text style={styles.insightDescription}>
                Intenta completar más tareas los miércoles para mantener el ritmo.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 30,
    textAlign: "center",
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 30,
  },
  statCard: {
    width: (width - 50) / 2,
    backgroundColor: "white",
    padding: 20,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginTop: 10,
  },
  statLabel: {
    fontSize: 14,
    color: "#666",
    marginTop: 5,
    textAlign: "center",
  },
  chartContainer: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 12,
    marginBottom: 30,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
    textAlign: "center",
  },
  chart: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "flex-end",
    height: 150,
    marginBottom: 20,
  },
  chartBar: {
    alignItems: "center",
  },
  barContainer: {
    height: 120,
    width: 30,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  bar: {
    width: 20,
    borderRadius: 2,
  },
  completedBar: {
    backgroundColor: "#4CAF50",
  },
  pendingBar: {
    backgroundColor: "#FF9800",
  },
  dayLabel: {
    fontSize: 12,
    color: "#666",
    marginTop: 10,
  },
  legend: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 20,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  legendText: {
    fontSize: 14,
    color: "#666",
  },
  insightsContainer: {
    marginBottom: 30,
  },
  insightsTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
  },
  insightCard: {
    flexDirection: "row",
    backgroundColor: "white",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  insightText: {
    flex: 1,
    marginLeft: 15,
  },
  insightTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  insightDescription: {
    fontSize: 14,
    color: "#666",
    lineHeight: 20,
  },
})
