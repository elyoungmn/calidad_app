"use client"

import { useState } from "react"
import { View, Text, StyleSheet, Switch, TouchableOpacity, Alert, ScrollView } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import Icon from "react-native-vector-icons/Ionicons"

export default function SettingsScreen() {
  const [settings, setSettings] = useState({
    notifications: true,
    darkMode: false,
    autoSync: true,
    biometric: false,
  })

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  const handleLogout = () => {
    Alert.alert("Cerrar Sesión", "¿Estás seguro de que quieres cerrar sesión?", [
      { text: "Cancelar", style: "cancel" },
      { text: "Cerrar Sesión", onPress: () => Alert.alert("Sesión cerrada") },
    ])
  }

  const SettingItem = ({
    icon,
    title,
    subtitle,
    value,
    onToggle,
    showSwitch = true,
  }: {
    icon: string
    title: string
    subtitle?: string
    value?: boolean
    onToggle?: () => void
    showSwitch?: boolean
  }) => (
    <TouchableOpacity style={styles.settingItem} onPress={onToggle}>
      <View style={styles.settingLeft}>
        <Icon name={icon} size={24} color="#007AFF" />
        <View style={styles.settingText}>
          <Text style={styles.settingTitle}>{title}</Text>
          {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
        </View>
      </View>
      {showSwitch && (
        <Switch
          value={value}
          onValueChange={onToggle}
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={value ? "#007AFF" : "#f4f3f4"}
        />
      )}
      {!showSwitch && <Icon name="chevron-forward" size={20} color="#ccc" />}
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content}>
        <Text style={styles.title}>Configuración</Text>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferencias</Text>

          <SettingItem
            icon="notifications-outline"
            title="Notificaciones"
            subtitle="Recibir alertas y recordatorios"
            value={settings.notifications}
            onToggle={() => toggleSetting("notifications")}
          />

          <SettingItem
            icon="moon-outline"
            title="Modo Oscuro"
            subtitle="Cambiar apariencia de la app"
            value={settings.darkMode}
            onToggle={() => toggleSetting("darkMode")}
          />

          <SettingItem
            icon="sync-outline"
            title="Sincronización Automática"
            subtitle="Sincronizar datos automáticamente"
            value={settings.autoSync}
            onToggle={() => toggleSetting("autoSync")}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Seguridad</Text>

          <SettingItem
            icon="finger-print-outline"
            title="Autenticación Biométrica"
            subtitle="Usar huella dactilar o Face ID"
            value={settings.biometric}
            onToggle={() => toggleSetting("biometric")}
          />

          <SettingItem
            icon="lock-closed-outline"
            title="Cambiar Contraseña"
            subtitle="Actualizar tu contraseña"
            showSwitch={false}
            onToggle={() => Alert.alert("Cambiar Contraseña", "Funcionalidad próximamente")}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Soporte</Text>

          <SettingItem
            icon="help-circle-outline"
            title="Centro de Ayuda"
            subtitle="Preguntas frecuentes y soporte"
            showSwitch={false}
            onToggle={() => Alert.alert("Centro de Ayuda", "Abriendo centro de ayuda...")}
          />

          <SettingItem
            icon="mail-outline"
            title="Contactar Soporte"
            subtitle="Enviar un mensaje al equipo"
            showSwitch={false}
            onToggle={() => Alert.alert("Contactar Soporte", "Abriendo formulario de contacto...")}
          />

          <SettingItem
            icon="star-outline"
            title="Calificar App"
            subtitle="Ayúdanos con tu opinión"
            showSwitch={false}
            onToggle={() => Alert.alert("Calificar App", "Gracias por tu feedback!")}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Información</Text>

          <SettingItem
            icon="information-circle-outline"
            title="Acerca de"
            subtitle="Versión 1.0.0"
            showSwitch={false}
            onToggle={() => Alert.alert("Acerca de", "Mi App React Native v1.0.0")}
          />

          <SettingItem
            icon="document-text-outline"
            title="Términos y Condiciones"
            showSwitch={false}
            onToggle={() => Alert.alert("Términos", "Abriendo términos y condiciones...")}
          />

          <SettingItem
            icon="shield-checkmark-outline"
            title="Política de Privacidad"
            showSwitch={false}
            onToggle={() => Alert.alert("Privacidad", "Abriendo política de privacidad...")}
          />
        </View>

        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Icon name="log-out-outline" size={24} color="#FF5252" />
          <Text style={styles.logoutText}>Cerrar Sesión</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 30,
    textAlign: "center",
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 15,
    marginLeft: 5,
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "white",
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  settingLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  settingText: {
    marginLeft: 15,
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  settingSubtitle: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "white",
    padding: 15,
    borderRadius: 12,
    marginTop: 20,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: "#FF5252",
  },
  logoutText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FF5252",
    marginLeft: 10,
  },
})
